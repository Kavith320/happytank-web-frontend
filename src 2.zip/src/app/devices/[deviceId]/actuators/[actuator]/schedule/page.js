"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import {
  ArrowLeft,
  CalendarClock,
  RefreshCw,
  Save,
  ToggleLeft,
  ToggleRight,
  Trash2,
} from "lucide-react";

/* ---------------- time helpers ---------------- */

function pad2(n) {
  return String(n).padStart(2, "0");
}

function minutesToHHMM(m) {
  const mm = ((m % 1440) + 1440) % 1440;
  const h = Math.floor(mm / 60);
  const min = mm % 60;
  return `${pad2(h)}:${pad2(min)}`;
}

function durationSec(startMin, endMin) {
  // allow crossing midnight
  let d = endMin - startMin;
  if (d <= 0) d += 1440;
  return d * 60;
}

/**
 * Your backend uses 6-field cron:
 * sec min hour dom mon dow
 * Daily at start HH:MM:00
 */
function buildDailyCron(startMin) {
  const hour = Math.floor(startMin / 60);
  const min = startMin % 60;
  return `0 ${min} ${hour} * * *`;
}

/* ---------------- small ui ---------------- */

function Card({ title, right, children }) {
  return (
    <div className="rounded-2xl bg-white/5 ring-1 ring-white/10 p-4">
      <div className="mb-3 flex items-center justify-between gap-3">
        <div className="text-base font-semibold">{title}</div>
        {right}
      </div>
      {children}
    </div>
  );
}

function Badge({ ok, children }) {
  return (
    <span
      className={
        "inline-flex items-center gap-2 rounded-full px-3 py-1 text-sm ring-1 " +
        (ok
          ? "bg-emerald-500/15 text-emerald-200 ring-emerald-400/30"
          : "bg-white/10 text-white/80 ring-white/10")
      }
    >
      {children}
    </span>
  );
}

/* ---------------- Vertical time range slider ---------------- */

function VerticalTimeRange({ startMin, endMin, onChange, height = 360 }) {
  const [drag, setDrag] = useState(null); // "start" | "end" | null

  const toY = (min) => (min / 1439) * height;

  const fromY = (y) => {
    const clamped = Math.max(0, Math.min(height, y));
    const p = clamped / height;
    return Math.round(p * 1439);
  };

  const startY = toY(startMin);
  const endY = toY(endMin);

  const handlePointer = (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const y = e.clientY - rect.top;
    const m = fromY(y);

    // choose nearest handle if not dragging yet
    let target = drag;
    if (!target) {
      const ds = Math.abs(y - startY);
      const de = Math.abs(y - endY);
      target = ds <= de ? "start" : "end";
      setDrag(target);
    }

    if (target === "start") onChange(m, endMin);
    else onChange(startMin, m);
  };

  const onPointerDown = (e) => {
    e.preventDefault();
    handlePointer(e);
    e.currentTarget.setPointerCapture?.(e.pointerId);
  };

  const onPointerMove = (e) => {
    if (!drag) return;
    e.preventDefault();
    handlePointer(e);
  };

  const onPointerUp = () => setDrag(null);

  // selected window (split if crosses midnight)
  const crosses = endMin <= startMin;
  const segs = crosses
    ? [
        { a: startMin, b: 1439 },
        { a: 0, b: endMin },
      ]
    : [{ a: startMin, b: endMin }];

  return (
    <div className="flex gap-4">
      <div
        className="relative rounded-2xl bg-black/30 ring-1 ring-white/10"
        style={{ width: 84, height }}
        onPointerDown={onPointerDown}
        onPointerMove={onPointerMove}
        onPointerUp={onPointerUp}
        onPointerCancel={onPointerUp}
      >
        {/* hour marks */}
        {Array.from({ length: 25 }).map((_, i) => {
          const y = (i / 24) * height;
          return (
            <div key={i} className="absolute left-0 right-0" style={{ top: y }}>
              <div className="h-px bg-white/10" />
              <div className="absolute -right-12 -top-2 text-[10px] opacity-60">
                {pad2(i % 24)}:00
              </div>
            </div>
          );
        })}

        {/* selected segments */}
        {segs.map((s, idx) => {
          const top = toY(s.a);
          const bot = toY(s.b);
          const hSeg = Math.max(2, bot - top);
          return (
            <div
              key={idx}
              className="absolute left-2 right-2 rounded-xl bg-emerald-500/20 ring-1 ring-emerald-400/25"
              style={{ top, height: hSeg }}
            />
          );
        })}

        {/* start handle */}
        <div className="absolute left-1 right-1 -translate-y-1/2" style={{ top: startY }}>
          <div className="w-full rounded-xl bg-white/10 ring-1 ring-white/20 px-2 py-1 text-[11px] text-center">
            Start
          </div>
        </div>

        {/* end handle */}
        <div className="absolute left-1 right-1 -translate-y-1/2" style={{ top: endY }}>
          <div className="w-full rounded-xl bg-white/10 ring-1 ring-white/20 px-2 py-1 text-[11px] text-center">
            End
          </div>
        </div>

        <div className="absolute left-2 bottom-2 text-[10px] opacity-60">Drag handles</div>
      </div>

      <div className="flex flex-col justify-between">
        <div className="space-y-2">
          <div className="rounded-xl bg-black/20 ring-1 ring-white/10 px-3 py-2">
            <div className="text-xs opacity-70">Start</div>
            <div className="text-sm font-semibold">{minutesToHHMM(startMin)}</div>
          </div>

          <div className="rounded-xl bg-black/20 ring-1 ring-white/10 px-3 py-2">
            <div className="text-xs opacity-70">End</div>
            <div className="text-sm font-semibold">{minutesToHHMM(endMin)}</div>
          </div>

          <div className="rounded-xl bg-black/20 ring-1 ring-white/10 px-3 py-2">
            <div className="text-xs opacity-70">Duration</div>
            <div className="text-sm font-semibold">
              {Math.round(durationSec(startMin, endMin) / 60)} min
            </div>
            {endMin <= startMin ? (
              <div className="mt-1 text-[10px] opacity-60">Crosses midnight</div>
            ) : null}
          </div>
        </div>

        <div className="text-[11px] opacity-60 max-w-[220px]">
          This creates a daily schedule at the selected start time and runs for the duration.
        </div>
      </div>
    </div>
  );
}

/* ---------------- SAFE api helpers ---------------- */

function safeMsg(e) {
  const m = e?.message ? String(e.message) : String(e || "Unknown error");
  // avoid dumping huge HTML/scripts into UI
  if (m.includes("<html") || m.includes("<script") || m.includes("__NEXT_DATA__")) {
    return "Server returned an unexpected response (not JSON). Check console/network.";
  }
  return m.slice(0, 300);
}

async function apiJson(path, method = "GET", body) {
  const res = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json" },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
    cache: "no-store",
  });

  const contentType = res.headers.get("content-type") || "";

  // ✅ If backend/proxy returns HTML, do NOT render it. Throw clean error.
  if (!contentType.includes("application/json")) {
    const text = await res.text();
    console.error("Non-JSON response from", path, "status", res.status, "body:", text);
    throw new Error("Server returned non-JSON response (check console/network).");
  }

  const data = await res.json();

  if (!res.ok || data?.ok === false) {
    throw new Error(data?.error || data?.message || `Request failed (${res.status})`);
  }

  return data;
}

/* ---------------- page ---------------- */

export default function ActuatorSchedulePage() {
  const { deviceId, actuator } = useParams();
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [busyId, setBusyId] = useState("");
  const [error, setError] = useState("");

  const [schedules, setSchedules] = useState([]);

  // create form
  const [name, setName] = useState("");
  const [enabled, setEnabled] = useState(true);
  const [timezone, setTimezone] = useState("Asia/Colombo");

  // slider minutes
  const [startMin, setStartMin] = useState(7 * 60); // 07:00
  const [endMin, setEndMin] = useState(7 * 60 + 5); // 07:05

  const load = useCallback(async () => {
    setError("");
    setLoading(true);
    try {
      const data = await apiJson(`/api/schedules/devices/${deviceId}/schedules`, "GET");
      const list = Array.isArray(data?.schedules) ? data.schedules : [];

      // filter schedules that affect this actuator
      const filtered = list.filter((s) => {
        const a1 = Array.isArray(s.actions) ? s.actions : [];
        const a2 = Array.isArray(s.end_actions) ? s.end_actions : [];
        return (
          a1.some((x) => x?.actuator === actuator) ||
          a2.some((x) => x?.actuator === actuator)
        );
      });

      setSchedules(filtered);
    } catch (e) {
      setError(safeMsg(e));
    } finally {
      setLoading(false);
    }
  }, [deviceId, actuator]);

  useEffect(() => {
    load();
  }, [load]);

  const preview = useMemo(() => {
    const cron = buildDailyCron(startMin);
    const dur = durationSec(startMin, endMin);
    return { cron, duration_sec: dur };
  }, [startMin, endMin]);

  const saveNew = async () => {
    setError("");
    setSaving(true);
    try {
      const nm = name.trim() || `${actuator} schedule`;

      const body = {
        name: nm,
        enabled,
        timezone,
        cron: preview.cron,
        actions: [{ actuator, set: { state: "ON", auto: true } }],
        duration_sec: preview.duration_sec,
        end_actions: [{ actuator, set: { state: "OFF", auto: true } }],
      };

      await apiJson(`/api/schedules/devices/${deviceId}/schedules`, "POST", body);

      setName("");
      await load();
    } catch (e) {
      setError(safeMsg(e));
    } finally {
      setSaving(false);
    }
  };

  const toggleEnabled = async (s) => {
    const id = s?._id;
    if (!id) return;
    setError("");
    setBusyId(id);
    try {
      await apiJson(`/api/schedules/${id}`, "PUT", { enabled: !s.enabled });
      await load();
    } catch (e) {
      setError(safeMsg(e));
    } finally {
      setBusyId("");
    }
  };

  const deleteSchedule = async (s) => {
    const id = s?._id;
    if (!id) return;
    setError("");
    setBusyId(id);
    try {
      await apiJson(`/api/schedules/${id}`, "DELETE");
      await load();
    } catch (e) {
      setError(safeMsg(e));
    } finally {
      setBusyId("");
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="rounded-2xl bg-white/5 ring-1 ring-white/10 p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="text-xs opacity-70">Actuator Scheduler</div>
            <div className="text-xl font-bold">{actuator}</div>
            <div className="mt-1 text-xs opacity-70">
              Device: <span className="opacity-90">{deviceId}</span>
            </div>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => router.back()}
              className="rounded-xl bg-white/10 hover:bg-white/15 ring-1 ring-white/10 px-4 py-2 text-sm inline-flex items-center gap-2"
            >
              <ArrowLeft className="h-4 w-4" />
              Back
            </button>

            <button
              onClick={load}
              className="rounded-xl bg-white/10 hover:bg-white/15 ring-1 ring-white/10 px-4 py-2 text-sm inline-flex items-center gap-2"
              disabled={loading}
            >
              <RefreshCw className={"h-4 w-4 " + (loading ? "animate-spin" : "")} />
              Refresh
            </button>
          </div>
        </div>

        {error ? (
          <div className="mt-3 rounded-xl bg-rose-500/10 ring-1 ring-rose-400/20 p-3 text-sm text-rose-100">
            {error}
          </div>
        ) : null}
      </div>

      {/* Create */}
      <Card
        title="Create new schedule"
        right={
          <div className="text-xs opacity-70 flex items-center gap-2">
            <CalendarClock className="h-4 w-4" />
            Daily schedule
          </div>
        }
      >
        <div className="grid gap-4 lg:grid-cols-2">
          <div className="space-y-3">
            <div>
              <div className="text-xs opacity-70">Name</div>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={`${actuator} schedule`}
                className="mt-1 w-full rounded-xl bg-black/30 ring-1 ring-white/10 px-3 py-2 text-sm"
              />
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <div className="text-xs opacity-70">Timezone</div>
                <input
                  value={timezone}
                  onChange={(e) => setTimezone(e.target.value)}
                  className="mt-1 w-full rounded-xl bg-black/30 ring-1 ring-white/10 px-3 py-2 text-sm"
                />
              </div>

              <div className="flex items-end gap-2">
                <button
                  type="button"
                  onClick={() => setEnabled((v) => !v)}
                  className="mt-1 w-full rounded-xl bg-white/10 hover:bg-white/15 ring-1 ring-white/10 px-3 py-2 text-sm inline-flex items-center justify-center gap-2"
                >
                  {enabled ? (
                    <>
                      <ToggleRight className="h-5 w-5" /> Enabled
                    </>
                  ) : (
                    <>
                      <ToggleLeft className="h-5 w-5" /> Disabled
                    </>
                  )}
                </button>
              </div>
            </div>

            <div className="rounded-2xl bg-black/20 ring-1 ring-white/10 p-3 text-sm">
              <div className="flex flex-wrap items-center gap-2">
                <Badge ok>Will run</Badge>
                <span className="opacity-70">
                  Start {minutesToHHMM(startMin)} → End {minutesToHHMM(endMin)}
                </span>
              </div>
              <div className="mt-2 text-xs opacity-70">
                Cron preview: <span className="opacity-100">{preview.cron}</span>
                <br />
                Duration: <span className="opacity-100">{preview.duration_sec}s</span>
              </div>
            </div>

            <button
              onClick={saveNew}
              disabled={saving}
              className="rounded-xl bg-emerald-500/15 hover:bg-emerald-500/20 ring-1 ring-emerald-400/30 px-4 py-2 text-sm inline-flex items-center gap-2"
            >
              <Save className="h-4 w-4" />
              {saving ? "Saving..." : "Save Schedule"}
            </button>
          </div>

          <div>
            <VerticalTimeRange
              startMin={startMin}
              endMin={endMin}
              onChange={(s, e) => {
                setStartMin(s);
                setEndMin(e);
              }}
              height={360}
            />
          </div>
        </div>
      </Card>

      {/* List */}
      <Card title={`Schedules for ${actuator}`}>
        {loading ? (
          <div className="text-sm opacity-70">Loading…</div>
        ) : schedules.length === 0 ? (
          <div className="text-sm opacity-70">No schedules for this actuator yet.</div>
        ) : (
          <div className="space-y-2">
            {schedules.map((s) => (
              <div key={s._id} className="rounded-2xl bg-black/20 ring-1 ring-white/10 p-4">
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div>
                    <div className="text-sm font-semibold">{s.name}</div>
                    <div className="mt-1 text-xs opacity-70">
                      Cron: <span className="opacity-100">{s.cron}</span> • TZ:{" "}
                      <span className="opacity-100">{s.timezone}</span>
                      {s.duration_sec != null ? (
                        <>
                          {" "}
                          • Duration: <span className="opacity-100">{s.duration_sec}s</span>
                        </>
                      ) : null}
                    </div>
                    <div className="mt-2 text-xs opacity-70">
                      Enabled: <span className="opacity-100">{s.enabled ? "Yes" : "No"}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => toggleEnabled(s)}
                      disabled={busyId === s._id}
                      className="rounded-xl bg-white/10 hover:bg-white/15 ring-1 ring-white/10 px-3 py-2 text-sm"
                    >
                      {s.enabled ? "Disable" : "Enable"}
                    </button>

                    <button
                      onClick={() => deleteSchedule(s)}
                      disabled={busyId === s._id}
                      className="rounded-xl bg-rose-500/15 hover:bg-rose-500/20 ring-1 ring-rose-400/30 px-3 py-2 text-sm inline-flex items-center gap-2"
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
